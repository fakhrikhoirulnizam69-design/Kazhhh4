package id.gema.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GemaColors = darkColorScheme(
    primary = Color(0xFFFF7A59),
    onPrimary = Color(0xFF10131A),
    background = Color(0xFF10131A),
    onBackground = Color(0xFFEDEFF5),
    surface = Color(0xFF181C26),
    onSurface = Color(0xFFEDEFF5),
    surfaceVariant = Color(0xFF232838),
    onSurfaceVariant = Color(0xFFA9B0C3),
    secondaryContainer = Color(0xFF2A3042),
    onSecondaryContainer = Color(0xFFEDEFF5),
)

@Composable
fun GemaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GemaColors, content = content)
}
