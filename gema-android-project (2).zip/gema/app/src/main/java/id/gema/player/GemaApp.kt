package id.gema.player

import android.app.Application
import id.gema.player.data.Catalog

class GemaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Catalog.init(this)
    }
}
