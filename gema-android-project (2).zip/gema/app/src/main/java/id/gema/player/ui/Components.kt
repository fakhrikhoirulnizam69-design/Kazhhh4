package id.gema.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import id.gema.player.data.LibraryViewModel
import id.gema.player.data.Track
import id.gema.player.player.PlayerUi
import id.gema.player.player.PlayerViewModel

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}

private val CoverPalette = listOf(
    Color(0xFFFF7A59),
    Color(0xFF6C8CFF),
    Color(0xFF3DDBB0),
    Color(0xFFB07CFF),
    Color(0xFFFFC857),
)

/** Sampul sementara berupa blok warna + huruf pertama. Ganti dengan gambar sampul asli nanti. */
@Composable
fun Cover(track: Track?, size: Dp, corner: Dp = 8.dp) {
    val color = CoverPalette[(track?.id?.hashCode() ?: 0).mod(CoverPalette.size)]
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(color),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = track?.title?.take(1) ?: "?",
            color = Color(0xFF10131A),
            fontWeight = FontWeight.Bold,
            fontSize = (size.value / 2.5f).sp,
        )
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
    )
}

@Composable
fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    player: PlayerViewModel,
    library: LibraryViewModel,
    removeLabel: String? = null,
    onRemove: (() -> Unit)? = null,
) {
    val liked by library.liked.collectAsStateWithLifecycle()
    val playlists by library.playlists.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var pickerOpen by remember { mutableStateOf(false) }
    val isLiked = liked.contains(track.id)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(track, 48.dp)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
        ) {
            Text(
                text = track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = track.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (isLiked) {
            Icon(
                imageVector = Icons.Rounded.Favorite,
                contentDescription = "Disukai",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menuOpen = false
                        player.playNext(track)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menuOpen = false
                        player.addToQueue(track)
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (isLiked) "Hapus dari disukai" else "Sukai") },
                    onClick = {
                        menuOpen = false
                        library.toggleLike(track.id)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke playlist") },
                    onClick = {
                        menuOpen = false
                        pickerOpen = true
                    },
                )
                if (removeLabel != null && onRemove != null) {
                    DropdownMenuItem(
                        text = { Text(removeLabel) },
                        onClick = {
                            menuOpen = false
                            onRemove()
                        },
                    )
                }
            }
        }
    }

    if (pickerOpen) {
        AlertDialog(
            onDismissRequest = { pickerOpen = false },
            title = { Text("Tambah ke playlist") },
            text = {
                if (playlists.isEmpty()) {
                    Text("Belum ada playlist. Buat dulu di tab Koleksi.")
                } else {
                    Column {
                        playlists.forEach { playlist ->
                            TextButton(
                                onClick = {
                                    library.addToPlaylist(playlist.id, track.id)
                                    pickerOpen = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(playlist.name, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pickerOpen = false }) { Text("Tutup") }
            },
        )
    }
}

@Composable
fun MiniPlayer(ui: PlayerUi, onOpen: () -> Unit, onToggle: () -> Unit) {
    val track = ui.current ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpen)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Cover(track, 44.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(
                        track.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onToggle) {
                    Icon(
                        imageVector = if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (ui.isPlaying) "Jeda" else "Putar",
                    )
                }
            }
            val progress = if (ui.durationMs > 0L) ui.positionMs.toFloat() / ui.durationMs.toFloat() else 0f
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
fun FavoriteIcon(liked: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(
            imageVector = if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            contentDescription = if (liked) "Hapus dari disukai" else "Sukai",
            tint = if (liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
    }
}
