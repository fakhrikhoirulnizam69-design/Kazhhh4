package id.gema.player.data

import android.content.Context
import org.json.JSONArray

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val url: String,
    val license: String,
)

data class Playlist(
    val id: String,
    val name: String,
    val trackIds: List<String>,
)

/**
 * Katalog dibaca dari assets/catalog.json. Untuk produk nyata, ganti file ini
 * (atau ganti dengan panggilan ke backend) dengan musik yang Anda punya lisensinya.
 */
object Catalog {
    var tracks: List<Track> = emptyList()
        private set

    private var index: Map<String, Track> = emptyMap()

    fun init(context: Context) {
        val raw = context.assets.open("catalog.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        val list = ArrayList<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Track(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    artist = o.optString("artist", ""),
                    album = o.optString("album", ""),
                    genre = o.optString("genre", ""),
                    url = o.getString("url"),
                    license = o.optString("license", ""),
                )
            )
        }
        tracks = list
        index = list.associateBy { track -> track.id }
    }

    fun byId(id: String?): Track? = if (id == null) null else index[id]

    fun search(query: String): List<Track> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return tracks.filter { track ->
            track.title.lowercase().contains(q) ||
                track.artist.lowercase().contains(q) ||
                track.album.lowercase().contains(q) ||
                track.genre.lowercase().contains(q)
        }
    }
}
