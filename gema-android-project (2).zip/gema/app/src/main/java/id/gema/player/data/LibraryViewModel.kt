package id.gema.player.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val store = LibraryStore(app)

    private val _liked = MutableStateFlow(store.loadLiked())
    val liked: StateFlow<Set<String>> = _liked.asStateFlow()

    private val _playlists = MutableStateFlow(store.loadPlaylists())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private val _recent = MutableStateFlow(store.loadRecent())
    val recent: StateFlow<List<String>> = _recent.asStateFlow()

    fun toggleLike(trackId: String) {
        val next = _liked.value.toMutableSet()
        if (!next.add(trackId)) next.remove(trackId)
        _liked.value = next
        store.saveLiked(next)
    }

    fun createPlaylist(name: String): String {
        val playlist = Playlist(UUID.randomUUID().toString(), name.trim(), emptyList())
        val next = _playlists.value + playlist
        _playlists.value = next
        store.savePlaylists(next)
        return playlist.id
    }

    fun deletePlaylist(playlistId: String) {
        val next = _playlists.value.filter { playlist -> playlist.id != playlistId }
        _playlists.value = next
        store.savePlaylists(next)
    }

    fun addToPlaylist(playlistId: String, trackId: String) {
        val next = _playlists.value.map { playlist ->
            if (playlist.id == playlistId) playlist.copy(trackIds = playlist.trackIds + trackId) else playlist
        }
        _playlists.value = next
        store.savePlaylists(next)
    }

    fun removeFromPlaylist(playlistId: String, position: Int) {
        val next = _playlists.value.map { playlist ->
            if (playlist.id == playlistId && position in playlist.trackIds.indices) {
                playlist.copy(trackIds = playlist.trackIds.filterIndexed { i, _ -> i != position })
            } else {
                playlist
            }
        }
        _playlists.value = next
        store.savePlaylists(next)
    }

    fun addRecent(trackId: String) {
        val next = (listOf(trackId) + _recent.value.filter { id -> id != trackId }).take(30)
        _recent.value = next
        store.saveRecent(next)
    }
}
