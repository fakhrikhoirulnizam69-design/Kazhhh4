package id.gema.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import id.gema.player.data.Catalog
import id.gema.player.data.LibraryViewModel
import id.gema.player.data.Track
import id.gema.player.player.PlayerUi
import id.gema.player.player.PlayerViewModel

@Composable
fun HomeScreen(ui: PlayerUi, player: PlayerViewModel, library: LibraryViewModel) {
    val recentIds by library.recent.collectAsStateWithLifecycle()
    val recentTracks = recentIds.mapNotNull { id -> Catalog.byId(id) }
    val all = Catalog.tracks

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
    ) {
        item {
            Text(
                "Gema",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
        }
        if (recentTracks.isNotEmpty()) {
            item { SectionTitle("Terakhir diputar") }
            itemsIndexed(recentTracks) { index, track ->
                TrackRow(
                    track = track,
                    isCurrent = ui.current?.id == track.id,
                    onClick = { player.play(recentTracks, index) },
                    player = player,
                    library = library,
                )
            }
        }
        item { SectionTitle("Semua lagu") }
        itemsIndexed(all) { index, track ->
            TrackRow(
                track = track,
                isCurrent = ui.current?.id == track.id,
                onClick = { player.play(all, index) },
                player = player,
                library = library,
            )
        }
    }
}

@Composable
fun SearchScreen(ui: PlayerUi, player: PlayerViewModel, library: LibraryViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    val results = Catalog.search(query)

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Cari lagu, artis, atau album") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        )
        when {
            query.isBlank() -> Text(
                "Ketik untuk mencari di katalog.",
                modifier = Modifier.padding(top = 24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            results.isEmpty() -> Text(
                "Tidak ada hasil untuk \"$query\".",
                modifier = Modifier.padding(top = 24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            else -> LazyColumn(modifier = Modifier.fillMaxSize().padding(top = 8.dp)) {
                itemsIndexed(results) { index, track ->
                    TrackRow(
                        track = track,
                        isCurrent = ui.current?.id == track.id,
                        onClick = { player.play(results, index) },
                        player = player,
                        library = library,
                    )
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(
    onOpenPlaylist: (String) -> Unit,
    onOpenLiked: () -> Unit,
    library: LibraryViewModel,
) {
    val playlists by library.playlists.collectAsStateWithLifecycle()
    val liked by library.liked.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableStateOf("semua") }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Koleksi",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            IconButton(onClick = { creating = true }) {
                Icon(Icons.Rounded.Add, contentDescription = "Buat playlist")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            FilterChip(selected = filter == "semua", onClick = { filter = "semua" }, label = { Text("Semua") })
            FilterChip(selected = filter == "playlist", onClick = { filter = "playlist" }, label = { Text("Playlist") })
            FilterChip(selected = filter == "disukai", onClick = { filter = "disukai" }, label = { Text("Disukai") })
        }
        LazyColumn {
            if (filter != "playlist") {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenLiked)
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.Favorite,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp),
                        )
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Lagu disukai", fontWeight = FontWeight.SemiBold)
                            Text(
                                "${liked.size} lagu",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            if (filter != "disukai") {
                if (playlists.isEmpty()) {
                    item {
                        Text(
                            "Belum ada playlist. Ketuk + untuk membuat.",
                            modifier = Modifier.padding(top = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                itemsIndexed(playlists) { _, playlist ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlaylist(playlist.id) }
                            .padding(vertical = 10.dp),
                    ) {
                        Text(playlist.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${playlist.trackIds.size} lagu",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }

    if (creating) {
        AlertDialog(
            onDismissRequest = { creating = false },
            title = { Text("Playlist baru") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("Nama playlist") },
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newName.isNotBlank()) {
                            library.createPlaylist(newName)
                            newName = ""
                            creating = false
                        }
                    },
                ) { Text("Buat") }
            },
            dismissButton = {
                TextButton(onClick = { creating = false }) { Text("Batal") }
            },
        )
    }
}

@Composable
private fun TrackListScreen(
    title: String,
    tracks: List<Track>,
    ui: PlayerUi,
    player: PlayerViewModel,
    library: LibraryViewModel,
    onBack: () -> Unit,
    onDelete: (() -> Unit)?,
    onRemoveAt: ((Int) -> Unit)?,
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Kembali")
            }
            Text(
                title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Hapus playlist")
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            Button(onClick = { player.play(tracks, 0) }, enabled = tracks.isNotEmpty()) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Text("Putar")
            }
            OutlinedButton(onClick = { player.playShuffled(tracks) }, enabled = tracks.isNotEmpty()) {
                Icon(Icons.Rounded.Shuffle, contentDescription = null)
                Text("Acak")
            }
        }
        if (tracks.isEmpty()) {
            Text(
                "Belum ada lagu.",
                modifier = Modifier.padding(top = 16.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        LazyColumn {
            itemsIndexed(tracks) { index, track ->
                TrackRow(
                    track = track,
                    isCurrent = ui.current?.id == track.id,
                    onClick = { player.play(tracks, index) },
                    player = player,
                    library = library,
                    removeLabel = if (onRemoveAt != null) "Hapus dari playlist" else null,
                    onRemove = if (onRemoveAt != null) ({ onRemoveAt(index) }) else null,
                )
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlistId: String,
    ui: PlayerUi,
    player: PlayerViewModel,
    library: LibraryViewModel,
    onBack: () -> Unit,
) {
    val playlists by library.playlists.collectAsStateWithLifecycle()
    val playlist = playlists.firstOrNull { p -> p.id == playlistId }
    if (playlist == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val tracks = playlist.trackIds.mapNotNull { id -> Catalog.byId(id) }
    TrackListScreen(
        title = playlist.name,
        tracks = tracks,
        ui = ui,
        player = player,
        library = library,
        onBack = onBack,
        onDelete = {
            library.deletePlaylist(playlist.id)
            onBack()
        },
        onRemoveAt = { position -> library.removeFromPlaylist(playlist.id, position) },
    )
}

@Composable
fun LikedScreen(
    ui: PlayerUi,
    player: PlayerViewModel,
    library: LibraryViewModel,
    onBack: () -> Unit,
) {
    val liked by library.liked.collectAsStateWithLifecycle()
    val tracks = Catalog.tracks.filter { track -> liked.contains(track.id) }
    TrackListScreen(
        title = "Lagu disukai",
        tracks = tracks,
        ui = ui,
        player = player,
        library = library,
        onBack = onBack,
        onDelete = null,
        onRemoveAt = null,
    )
}
