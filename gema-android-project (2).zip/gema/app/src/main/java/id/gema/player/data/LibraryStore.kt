package id.gema.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan lokal sederhana (SharedPreferences): lagu disukai, playlist, riwayat. */
class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("gema_library", Context.MODE_PRIVATE)

    fun loadLiked(): Set<String> = (prefs.getStringSet("liked", emptySet()) ?: emptySet()).toSet()

    fun saveLiked(ids: Set<String>) {
        prefs.edit().putStringSet("liked", ids.toSet()).apply()
    }

    fun loadRecent(): List<String> {
        val raw = prefs.getString("recent", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) out.add(arr.getString(i))
        return out
    }

    fun saveRecent(ids: List<String>) {
        val arr = JSONArray()
        ids.forEach { id -> arr.put(id) }
        prefs.edit().putString("recent", arr.toString()).apply()
    }

    fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString("playlists", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = ArrayList<Playlist>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("tracks")
            val trackIds = ArrayList<String>()
            for (j in 0 until ids.length()) trackIds.add(ids.getString(j))
            out.add(Playlist(o.getString("id"), o.getString("name"), trackIds))
        }
        return out
    }

    fun savePlaylists(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { playlist ->
            val o = JSONObject()
            o.put("id", playlist.id)
            o.put("name", playlist.name)
            val ids = JSONArray()
            playlist.trackIds.forEach { id -> ids.put(id) }
            o.put("tracks", ids)
            arr.put(o)
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }
}
