package id.gema.player

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import id.gema.player.data.LibraryViewModel
import id.gema.player.player.PlayerViewModel
import id.gema.player.ui.GemaTheme
import id.gema.player.ui.HomeScreen
import id.gema.player.ui.LibraryScreen
import id.gema.player.ui.LikedScreen
import id.gema.player.ui.MiniPlayer
import id.gema.player.ui.NowPlayingScreen
import id.gema.player.ui.PlaylistDetailScreen
import id.gema.player.ui.SearchScreen

private sealed interface Detail {
    data class PlaylistD(val id: String) : Detail
    data object Liked : Detail
}

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            GemaTheme {
                GemaRoot()
            }
        }
    }
}

@Composable
private fun GemaRoot() {
    val player: PlayerViewModel = viewModel()
    val library: LibraryViewModel = viewModel()
    val ui by player.ui.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showNowPlaying by remember { mutableStateOf(false) }

    LaunchedEffect(ui.current?.id) {
        ui.current?.id?.let { id -> library.addRecent(id) }
    }

    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }
    BackHandler(enabled = !showNowPlaying && detail != null) { detail = null }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    MiniPlayer(
                        ui = ui,
                        onOpen = { showNowPlaying = true },
                        onToggle = { player.togglePlay() },
                    )
                    NavigationBar {
                        NavigationBarItem(
                            selected = tab == 0,
                            onClick = { tab = 0; detail = null },
                            icon = { Icon(Icons.Rounded.Home, contentDescription = null) },
                            label = { Text("Beranda") },
                        )
                        NavigationBarItem(
                            selected = tab == 1,
                            onClick = { tab = 1; detail = null },
                            icon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                            label = { Text("Cari") },
                        )
                        NavigationBarItem(
                            selected = tab == 2,
                            onClick = { tab = 2; detail = null },
                            icon = { Icon(Icons.Rounded.LibraryMusic, contentDescription = null) },
                            label = { Text("Koleksi") },
                        )
                    }
                }
            },
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                val currentDetail = detail
                when {
                    currentDetail is Detail.PlaylistD -> PlaylistDetailScreen(
                        playlistId = currentDetail.id,
                        ui = ui,
                        player = player,
                        library = library,
                        onBack = { detail = null },
                    )
                    currentDetail is Detail.Liked -> LikedScreen(
                        ui = ui,
                        player = player,
                        library = library,
                        onBack = { detail = null },
                    )
                    tab == 0 -> HomeScreen(ui, player, library)
                    tab == 1 -> SearchScreen(ui, player, library)
                    else -> LibraryScreen(
                        onOpenPlaylist = { id -> detail = Detail.PlaylistD(id) },
                        onOpenLiked = { detail = Detail.Liked },
                        library = library,
                    )
                }
            }
        }

        if (showNowPlaying) {
            NowPlayingScreen(
                ui = ui,
                player = player,
                library = library,
                onClose = { showNowPlaying = false },
            )
        }
    }
}
