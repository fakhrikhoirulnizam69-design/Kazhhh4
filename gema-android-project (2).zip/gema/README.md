# Gema (nama sementara)

Pemutar musik Android: Kotlin, Jetpack Compose, Media3. Dibuat berdasarkan peta di `replica/recon.md` dan `replica/architecture.md`.

## Isi versi 0.1 (MVP)

- Tiga tab: Beranda, Cari, Koleksi
- Pemutaran di latar belakang dengan notifikasi media dan kontrol layar kunci
- Mini-player dan layar Now Playing (seek, putar/jeda, berikutnya/sebelumnya, acak, ulangi)
- Antrean (lihat, lompat, hapus), "Putar berikutnya", "Tambah ke antrean"
- Playlist (buat, tambah/hapus lagu, hapus), lagu disukai, terakhir diputar
- Pencarian di katalog

Belum ada: login, backend, unduhan offline, langganan/pembayaran, lirik, sampul gambar. Semua tersimpan lokal di perangkat.

## Cara mendapatkan APK

### Cara 1: GitHub Actions (tanpa komputer, cukup browser)
1. Buat repositori baru di GitHub, unggah isi folder ini (termasuk `.github`).
2. Buka tab **Actions**, jalankan **Build APK** (atau tunggu otomatis setelah push ke `main`).
3. Setelah hijau, buka run-nya dan unduh artifact **gema-debug-apk** (zip berisi `app-debug.apk`).
4. Ekstrak, kirim ke ponsel, izinkan "instal dari sumber tidak dikenal", lalu instal.

### Cara 2: Android Studio
Buka folder ini, tunggu sinkronisasi Gradle, lalu **Build > Build APK(s)**. File ada di `app/build/outputs/apk/debug/`.

### Cara 3: Terminal
```
./gradlew assembleDebug
```
Butuh JDK 17 dan Android SDK (platform 35).

## Katalog musik

Isi `app/src/main/assets/catalog.json` hanya contoh uji (6 lagu demo dari situs SoundHelix, belum diverifikasi lisensinya untuk dipakai komersial). **Ganti sebelum rilis** dengan musik yang Anda punya lisensinya. Setiap lagu punya kolom `license` untuk mencatat sumber lisensinya.

## Sebelum dijual

- Cek merek dagang nama "Gema" dan ganti kalau perlu (`applicationId`, nama aplikasi, ikon).
- APK debug ditandatangani kunci debug. Untuk Google Play, buat keystore sendiri dan unggah AAB (`./gradlew bundleRelease`).
- Langganan digital di Android wajib lewat Google Play Billing.
- Siapkan kebijakan hak cipta dan alur pelaporan konten untuk Google Play.
- Jangan memakai katalog atau API Spotify. Developer Policy-nya melarang monetisasi aplikasi streaming.
- Ini bukan nasihat hukum; konsultasi ke pengacara sebelum meluncur.
